# Microsoft Demo

Workflow summary:
 1. Show the production app at http://githubookstore.azurewebsites.net/
 2. Go into board and pick up a task
 3. Go into the repo, checkout, work on the issue AB#?
 4. If the app has 6 books remove 3, if it has 3 add another 3, simple change.
 5. Show the statuses and the deployment 
 6. If they all pass show the production update
 
 Extras to be worked on:
  - Deployment API
  - Different workflow on merge to main or another event (pre prod vs prod)
